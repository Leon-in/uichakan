export const productImages = [
  {
    url: "https://siweihaiyang-1327461466.cos.ap-guangzhou.myqcloud.com/官网学习机图片/学习机新2改3.jpg",
    alt: "AI学习机整体展示"
  },
  {
    url: "https://siweihaiyang-1327461466.cos.ap-guangzhou.myqcloud.com/官网学习机图片/主图2改2.jpg",
    alt: "AI学习机正面视图"
  },
  {
    url: "https://siweihaiyang-1327461466.cos.ap-guangzhou.myqcloud.com/官网学习机图片/主图3.jpg",
    alt: "AI学习机侧面视图"
  },
  {
    url: "https://siweihaiyang-1327461466.cos.ap-guangzhou.myqcloud.com/官网学习机图片/主图4.jpg",
    alt: "AI学习机使用场景"
  },
  {
    url: "https://siweihaiyang-1327461466.cos.ap-guangzhou.myqcloud.com/官网学习机图片/主图5改.jpg",
    alt: "AI学习机功能展示"
  }
]

