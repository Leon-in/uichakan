import Link from 'next/link'

export function Footer() {
  return (
    <footer className="border-t bg-gray-50/50">
      <div className="container py-12 md:py-16 lg:py-20">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          <div className="col-span-2 md:col-span-1">
            <div className="space-y-3">
              <h3 className="text-lg font-bold">思维海洋</h3>
              <p className="text-sm text-muted-foreground">
                珠海新时代教育科技有限公司
              </p>
              <p className="text-sm text-muted-foreground">
                开启新时代教育的新章程
              </p>
            </div>
          </div>
          <div>
            <h4 className="font-semibold mb-4">解决方案</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/ai-model" className="text-muted-foreground hover:text-foreground">
                  AI大模型
                </Link>
              </li>
              <li>
                <Link href="/ai-learning-machine" className="text-muted-foreground hover:text-foreground">
                  AI学习机
                </Link>
              </li>
              <li>
                <Link href="/solutions/smart-room" className="text-muted-foreground hover:text-foreground">
                  AI智习室
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-4">关于我们</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/about" className="text-muted-foreground hover:text-foreground">
                  公司介绍
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-muted-foreground hover:text-foreground">
                  联系我们
                </Link>
              </li>
              <li>
                <Link href="/about#join-us" className="text-muted-foreground hover:text-foreground">
                  加入我们
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-4">联系方式</h4>
            <ul className="space-y-2 text-sm">
              <li className="text-muted-foreground">
                电话：0756-1234567
              </li>
              <li className="text-muted-foreground">
                邮箱：contact@siweihaiyang.com
              </li>
              <li className="text-muted-foreground">
                地址：珠海市香洲区
              </li>
            </ul>
          </div>
        </div>
        <div className="mt-12 pt-8 border-t text-center text-sm text-muted-foreground">
          <p>© 2024 珠海新时代教育科技有限公司. 保留所有权利.</p>
        </div>
      </div>
    </footer>
  )
}

